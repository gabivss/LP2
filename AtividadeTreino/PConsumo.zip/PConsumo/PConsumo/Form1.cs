﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string aux = "";
            double[,] consumo = new double[5, 4];
            string[] setores = { "Produção", "Escritório", "Refeitório", "Limpeza", "Logística"};
            int i;
            int j;

            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    aux = Interaction.InputBox("Digite o consumo do setor: " + setores[i] + " na semana " + (j + 1));
                    if (aux == "")
                        return;
                    while (!Double.TryParse(aux, out consumo[i,j]) || consumo[i,j] < 0)
                    {
                        MessageBox.Show("Valor inválido! Digite um número maior ou igual a 0!");
                        aux = Interaction.InputBox("Digite o consumo do setor: " + setores[i] + " na semana " + (j + 1));
                    }
                }
            }

            double[] TotalSetor = new double[5];
            double TotalGeral;
            double soma;
            TotalGeral = 0;

            for (i = 0; i < 5; i++)
            {
                soma = 0;
                for (j = 0; j < 4; j++)
                {
                    soma = soma + consumo[i, j];
                }
                TotalGeral = TotalGeral + soma;
                TotalSetor[i] = soma;
            }

            for (i = 0; i < 5; i++)
            {
                lstbxResultado.Items.Add(setores[i] + ":" + TotalSetor[i] + " -> " + (TotalSetor[i] * 0.01).ToString("C2"));
            }
            lstbxResultado.Items.Add("-----------------------");
            lstbxResultado.Items.Add("TotalGeral : " + TotalGeral + (TotalGeral * 0.01).ToString("C2"));


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}
