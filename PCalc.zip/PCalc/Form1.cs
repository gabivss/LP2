﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        Double numeroum;
        Double numerodois;
        Double resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl==btnSair)
            {
                return;
            }
            if (!double.TryParse(txtNum1.Text, out numeroum)) 
            { 
                MessageBox.Show("Digite um valor válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum1.Focus();
            
            
            }


        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(txtNum2.Text, out numerodois))
            {
                MessageBox.Show("Digite um valor válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();


            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numeroum + numerodois;
            txtResultado.Text = resultado.ToString("N2");

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numeroum - numerodois;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numeroum * numerodois;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numerodois == 0)
            {
                MessageBox.Show("Não é possível dividir por zero!",
                                "Erro",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }
            resultado = numeroum / numerodois;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();

            numeroum = 0;
            numerodois = 0;
            resultado = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
