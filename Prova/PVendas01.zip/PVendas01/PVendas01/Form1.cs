﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Vendas : Form
    {
        public Vendas()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string aux;
            double[,] vendas = new double[3, 4];
            string[] meses = { "1", "2", "3" };
            string[] semanas = { "1", "2", "3", "4"};
            int i;
            int j;

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    aux = Interaction.InputBox("Digite o valor da venda do mês: " + meses[i] + " na semana " + (j + 1));
                    if (aux == "")
                        return;
                    while (!Double.TryParse(aux, out vendas[i, j] ) || vendas[i, j] < 0)
                    {
                        MessageBox.Show("Valor inválido! Digite um número maior ou igual a 0!");
                        aux = Interaction.InputBox("Digite o valor da venda do mês: " + meses[i] + " na semana" + (j + 1));
                    }
                }
            }

            double[] TotalMes = new double[3];
            double TotalGeral;
            double soma;
            TotalGeral = 0;

            for (i = 0; i < 3; i++)
            {
                soma = 0;
                for(j = 0;j < 4; j++)
                {
                    soma = soma + vendas[i, j];
                }
                TotalGeral = TotalGeral + soma;
                TotalMes[i] = soma;
            }

            for (i = 0;i < 3;i++)
            {
                lstbxResultado.Items.Add("-----------------------------------------");
                for (j = 0; j < 4; j++)
                {
                    lstbxResultado.Items.Add("Total do mês: " + meses[i] + " Semana: " + semanas[j] + " -> " + (vendas[i, j]).ToString("F2"));

                }
                lstbxResultado.Items.Add("Total mês: " + meses[i] + " -> " + (TotalMes[i]).ToString("F2"));


            }
           
            lstbxResultado.Items.Add("-----------------------------------------");
            lstbxResultado.Items.Add("Total Geral: " + TotalGeral.ToString("F2"));
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}
