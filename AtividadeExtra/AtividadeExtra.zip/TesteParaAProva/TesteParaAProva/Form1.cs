﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace TesteParaAProva
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string aux; //criando a variavel para validar se é numero valido
            double[,] compras = new double[7, 5];// criando matriz para guardar as compras de cada dia
            string[] dias =
            {
                "Domingo",
                "Segunda",
                "Terça",
                "Quarta",
                "Quinta",
                "Sexta",
                "Sábado"

            }; //criando vetor para colocar os dias, pra depois ficar dias [i]
            int i;
            int j;

            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    aux = Interaction.InputBox("Digite o valor do produto " + (j + 1) + " no dia " + dias[i]);
                    if (aux == "")
                        return;
                    while (!Double.TryParse(aux,out compras[i,j]) || compras[i,j] < 0)
                    {
                        MessageBox.Show("Valor inválido! Digite um número maior ou igual a 0!");
                        aux = Interaction.InputBox("Digite novamente o valor do produto " + (j + i) + "no dia " + dias[i]);
                    }

                }


            }

            double [] TotalporDia = new double[7]; //criando vetor para guardar o valor de cada dia
            double TotalGeral;
            double soma;
            TotalGeral = 0;

            for (i = 0; i < 7; i++)
            {
                soma = 0;
                for (j = 0; j < 5; j++)
                {
                    soma = soma + compras[i, j];
                }
                TotalGeral = TotalGeral + soma;
                TotalporDia[i] = soma;

            }

            for (i = 0; i < 7; i++)
            {
                lstbxResultado.Items.Add(dias[i] + " : " + TotalporDia[i]);
               
            }
            lstbxResultado.Items.Add("-----------");
            lstbxResultado.Items.Add("TotalGeral : " + TotalGeral);

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}
