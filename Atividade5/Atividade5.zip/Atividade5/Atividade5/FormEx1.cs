﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class FormEx1 : Form
    {
        public FormEx1()
        {
            InitializeComponent();
        }

        private void btnFor_Click(object sender, EventArgs e)
        {
            string frase = rtbFrase.Text;
            int espacos = 0;
            int letrasR = 0;
            int pares = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == ' ')
                    espacos++;

                if (frase[i] == 'R' || frase[i] == 'r')
                    letrasR++;

                if (i < frase.Length - 1)
                {
                    if (frase[i] == frase[i + 1])
                        pares++;
                }
            }

            lblResultado.Text =
                $"Espaços: {espacos}\nR: {letrasR}\nPares: {pares}";
        }

        private void btnWhile_Click(object sender, EventArgs e)
        {
            string frase = rtbFrase.Text;
            int i = 0, espacos = 0, letrasR = 0, pares = 0;

            while (i < frase.Length)
            {
                if (frase[i] == ' ')
                    espacos++;

                if (frase[i] == 'R' || frase[i] == 'r')
                    letrasR++;

                if (i < frase.Length - 1)
                {
                    if (frase[i] == frase[i + 1])
                        pares++;
                }

                i++;
            }

            lblResultado.Text =
                $"Espaços: {espacos}\nR: {letrasR}\nPares: {pares}";
        }

        private void btnForeach_Click(object sender, EventArgs e)
        {
            string frase = rtbFrase.Text;
            int espacos = 0, letrasR = 0, pares = 0;

            char anterior = '\0';

            foreach (char c in frase)
            {
                if (c == ' ')
                    espacos++;

                if (c == 'R' || c == 'r')
                    letrasR++;

                if (c == anterior)
                    pares++;

                anterior = c;
            }

            lblResultado.Text =
                $"Espaços: {espacos}\nR: {letrasR}\nPares: {pares}";
        }
    }
}
