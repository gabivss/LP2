﻿using System;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class FormEx4 : Form
    {
        public FormEx4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;

            double producao = double.Parse(txtProducao.Text);
            double A = double.Parse(txtSalario.Text);
            double gratificacao = double.Parse(txtGratificacao.Text);

            int B = 0, C = 0, D = 0;

            if (producao >= 100) B = 1;
            if (producao >= 120) C = 1;
            if (producao >= 150) D = 1;

            double salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            if (salarioBruto > 7000)
            {
                if (!(producao >= 150 && gratificacao > 0))
                {
                    salarioBruto = 7000;
                }
            }

            lblResultado.Text =
                "Nome: " + nome +
                "\nMatrícula: " + matricula +
                "\nSalário Bruto: R$ " + salarioBruto.ToString("F2");
        }
    }
}