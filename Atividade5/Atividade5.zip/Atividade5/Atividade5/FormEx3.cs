﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class FormEx3 : Form
    {
        public FormEx3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text;

            frase = frase.Replace(" ", "");
            frase = RemoverAcentos(frase);
            frase = frase.ToUpper();

            bool ehPalindromo = true;

            for (int i = 0; i < frase.Length / 2; i++)
            {
                if (frase[i] != frase[frase.Length - 1 - i])
                {
                    ehPalindromo = false;
                    break;
                }
            }

            if (ehPalindromo)
                lblResultado.Text = "É PALÍNDROMO!";
            else
                lblResultado.Text = "NÃO É PALÍNDROMO!";
        }

        public static string RemoverAcentos(string texto)
        {
            var normalizedString = texto.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (char c in normalizedString)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }
    }
}