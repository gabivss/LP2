﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class FormEx2 : Form
    {
        public FormEx2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int N;
            double H = 0;

            if (int.TryParse(txtN.Text, out N))
            {
                if (N > 0)
                {
                    for (int i = 1; i <= N; i++)
                    {
                        H += 1.0 / i;
                    }

                    lblResultado.Text = "H = " + H.ToString("F4");
                }
                else
                {
                    lblResultado.Text = "N deve ser maior que 0!";
                }
            }
            else
            {
                lblResultado.Text = "Digite um número válido!";
            }
        }
    }
}
