﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        Double peso;
        Double altura;
        Double imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl==btnSair)
            {
                return;
            }

            if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Valor inválido para o peso. Por favor, insira um número válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPeso.Focus();
            }

            else
            {
                if (peso <= 0)
                {
                    MessageBox.Show("O peso deve ser um número maior que zero!");
                    txtPeso.Focus();
                }
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {

            {
                if (this.ActiveControl == btnSair)
                {
                    return;
                }

                if (!double.TryParse(txtAltura.Text, out altura))
                {
                    MessageBox.Show("Valor inválido para a altura. Por favor, insira um número válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtAltura.Focus();
                }

                else
                {
                    if (altura <= 0)
                    {
                        MessageBox.Show("A altura deve ser um número maior que zero!");
                        txtAltura.Focus();
                    }
                }
            }

        }

        private void txtIMC_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {

            imc = peso / Math.Pow(altura, 2);
            txtIMC.Text = imc.ToString();

            if (imc < 18.5)
            {
                txtIMC.Text = "Magreza";
            }
            else if (imc <= 24.9)
            {
                txtIMC.Text = "Normal";
            }
            else if (imc <= 29.9)
            {
                txtIMC.Text = "Sobrepeso";
            }
            else if (imc <= 39.9)
            {
                txtIMC.Text = "Obesidade";
            }
            else
            {
                txtIMC.Text = "Obesidade grave";
            }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtIMC.Clear();
            txtPeso.Clear();

            peso = 0;
            altura = 0;
            imc = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtPeso_Validated_1(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Valor inválido para o peso. Por favor, insira um número válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPeso.Focus();
            }

            else
            {
                if (peso <= 0)
                {
                    MessageBox.Show("O peso deve ser um número maior que zero!");
                    txtPeso.Focus();
                }
            }
        }
    }
    }

